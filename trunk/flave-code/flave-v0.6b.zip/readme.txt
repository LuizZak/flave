The Flash Verlet Engine - Flave v0.6b

This is the first public beta release of the Flave engine.
Many things are yet to be fixed and many features are half-baked,
but still, it's one nifty little engine that I'm sure will be
useful to someone!


Version History

Legend:
+ Feature add
- Feature remove
* Fix
. Note


v0.6b

. First public release


FLADE IS LICENSED UNDER THE MIT LICENSE. SEE LICENSE.TXT FOR MORE INFORMATION AND THE LICENSE.